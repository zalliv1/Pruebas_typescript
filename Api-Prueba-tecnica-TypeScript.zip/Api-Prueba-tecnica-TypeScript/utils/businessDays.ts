import { DateTime } from "luxon";

// Horario laboral en Colombia
const WORK_START_HOUR = 8;
const LUNCH_START_HOUR = 12;
const LUNCH_END_HOUR = 13;
const WORK_END_HOUR = 17;

// Zona horaria de Colombia
const COLOMBIA_ZONE = "America/Bogota";

// URL de festivos
const HOLIDAYS_URL = "https://content.capta.co/Recruitment/WorkingDays.json";

export interface BusinessTimeInput {
  days?: number;
  hours?: number;
  date?: string; // Fecha en UTC (ISO 8601 con Z)
}

export interface BusinessTimeResult {
  date: string; // Fecha final en UTC ISO 8601
}


async function getHolidays(): Promise<string[]> {
  const response = await fetch(HOLIDAYS_URL);
  const holidays: string[] = await response.json();
  return holidays;
}

function isWeekend(date: DateTime): boolean {
  return date.weekday === 6 || date.weekday === 7; // 6 = sábado, 7 = domingo
}

function isHoliday(date: DateTime, holidays: string[]): boolean {
  return holidays.includes(date.toISODate() || "");
}

function isBusinessDay(date: DateTime, holidays: string[]): boolean {
  return !isWeekend(date) && !isHoliday(date, holidays);
}

function adjustToWorkingHours(date: DateTime): DateTime {
  // Antes de las 8:00 → poner a las 8:00
  if (date.hour < WORK_START_HOUR) {
    return date.set({ hour: WORK_START_HOUR, minute: 0, second: 0 });
  }

  // Durante almuerzo → mover a 13:00
  if (date.hour >= LUNCH_START_HOUR && date.hour < LUNCH_END_HOUR) {
    return date.set({ hour: LUNCH_END_HOUR, minute: 0, second: 0 });
  }

  // Después de las 17:00 → siguiente día laboral a las 8:00
  if (date.hour >= WORK_END_HOUR) {
    return date.plus({ days: 1 }).set({ hour: WORK_START_HOUR, minute: 0, second: 0 });
  }

  return date;
}

export async function addBusinessTime(input: BusinessTimeInput): Promise<BusinessTimeResult> {
  if (!input.days && !input.hours) {
    throw new Error("Debe enviar al menos uno de los parámetros: days u hours");
  }

  const holidays = await getHolidays();

  // Si no hay fecha, tomar hora actual en Colombia
  let start = input.date
    ? DateTime.fromISO(input.date, { zone: "utc" }).setZone(COLOMBIA_ZONE)
    : DateTime.now().setZone(COLOMBIA_ZONE);

  // Ajustar si no es día laboral
  while (!isBusinessDay(start, holidays)) {
    start = start.plus({ days: 1 }).set({ hour: WORK_START_HOUR, minute: 0, second: 0 });
  }

  // Ajustar si está fuera de jornada
  start = adjustToWorkingHours(start);

  let result = start;

  // 1) Sumar días hábiles
  if (input.days && input.days > 0) {
    let daysToAdd = input.days;
    while (daysToAdd > 0) {
      result = result.plus({ days: 1 }).set({ hour: WORK_START_HOUR, minute: 0, second: 0 });
      if (isBusinessDay(result, holidays)) {
        daysToAdd--;
      }
    }
  }

  // 2) Sumar horas hábiles
  if (input.hours && input.hours > 0) {
    let hoursToAdd = input.hours;
    while (hoursToAdd > 0) {
      result = result.plus({ hours: 1 });

      // Saltar hora de almuerzo
      if (result.hour === LUNCH_START_HOUR) {
        result = result.set({ hour: LUNCH_END_HOUR });
      }

      // Si pasa de 17:00, ir al siguiente día hábil a las 8:00
      if (result.hour >= WORK_END_HOUR) {
        do {
          result = result.plus({ days: 1 }).set({ hour: WORK_START_HOUR, minute: 0, second: 0 });
        } while (!isBusinessDay(result, holidays));
      }

      hoursToAdd--;
    }
  }

  // Convertir resultado a UTC
  const finalDate = result.setZone("utc").toISO({ suppressMilliseconds: true });

  return { date: finalDate || "" };
}
